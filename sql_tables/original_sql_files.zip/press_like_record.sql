-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- 主機: 127.0.0.1:3306
-- 產生時間： 2018-06-10 16:34:44
-- 伺服器版本: 5.7.21
-- PHP 版本： 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `courseevaluationsystem`
--

-- --------------------------------------------------------

--
-- 資料表結構 `press_like_record`
--

DROP TABLE IF EXISTS `press_like_record`;
CREATE TABLE IF NOT EXISTS `press_like_record` (
  `username` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `comment_number` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`username`,`comment_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 資料表的匯出資料 `press_like_record`
--

INSERT INTO `press_like_record` (`username`, `comment_number`) VALUES
('990805', '32'),
('990805', '33'),
('990805', '34'),
('990805', '35'),
('s106062550', '33'),
('s106062550', '34');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
